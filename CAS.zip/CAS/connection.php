<?php
$servername = "localhost"; // or your server name
$username = "root"; // your database username
$password = ""; // your database password
$dbname = "CMS"; // your database name

// Create connection
    $database= new mysqli("localhost","root","","CMS");
    // Create connection
    if ($database->connect_error){
        die("Connection failed:  ".$database->connect_error);
    }

?>