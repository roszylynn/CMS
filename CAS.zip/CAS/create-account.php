<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/home.css">
    <link rel="stylesheet" href="css/signup1.css">
    <title>Create Account</title>
    <style>
        .container {
            animation: transitionIn-X 0.5s;
        }
        .strength {
            display: flex;
            justify-content: space-between;
            margin-top: 5px;
        }
        .strength span {
            width: 24%;
            height: 5px;
            background: lightgray;
        }
        .strength span.weak {
            background: red;
        }
        .strength span.medium {
            background: orange;
        }
        .strength span.strong {
            background: yellowgreen;
        }
        .strength span.very-strong {
            background: green;
        }
    </style>
</head>
<body>
    <!-- Navbar section -->
    <nav class="navbar">
        <div class="navbar__container">
            <a href="home.html" id="navbar__logo">CUEA COUNSELING</a>
            <div class="navbar__toggle" id="mobile-menu">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </div>
            <ul class="navbar__menu">
                <li class="navbar__item">
                    <a href="home.html" class="navbar__links">Home</a>
                </li>
                <li class="navbar__item">
                    <a href="counselor.html" class="navbar__links">Counselor</a>
                </li>
                <li class="navbar__item">
                    <a href="services.html" class="navbar__links">Services</a>
                </li>
                <li class="navbar__item">
                    <a href="contact.html" class="navbar__links">Contact</a>
                </li>
                <li class="navbar__btn">
                    <a href="login.php" class="button">Login</a>
                </li>
                <li class="navbar__btn">
                    <a href="login.php" class="button">Admin</a>
                </li>
            </ul>
        </div>
    </nav>

    <?php
session_start();

// Check if necessary keys are set in the session
if (!isset($_SESSION['personal']['regNo'])) {
    $_SESSION['personal']['regNo'] = ''; // Set a default value or handle appropriately
}
if (!isset($_SESSION['personal']['fname'])) {
    $_SESSION['personal']['fname'] = ''; // Set a default value or handle appropriately
}
if (!isset($_SESSION['personal']['lname'])) {
    $_SESSION['personal']['lname'] = ''; // Set a default value or handle appropriately
}
if (!isset($_SESSION['personal']['address'])) {
    $_SESSION['personal']['address'] = ''; // Set a default value or handle appropriately
}
if (!isset($_SESSION['personal']['dob'])) {
    $_SESSION['personal']['dob'] = ''; // Set a default value or handle appropriately
}

$_SESSION["user"] = "";
$_SESSION["usertype"] = "";

// Set the new timezone
date_default_timezone_set('Africa/Nairobi');
$date = date('Y-m-d');
$_SESSION["date"] = $date;

// Import database
include("connection.php");

$error = '';

if ($_POST) {
    $fname = $_SESSION['personal']['fname'];
    $lname = $_SESSION['personal']['lname'];
    $name = $fname . " " . $lname;
    $address = $_SESSION['personal']['address'];
    $regNo = $_SESSION['personal']['regNo'];
    $dob = $_SESSION['personal']['dob'];
    $email = $_POST['newemail'];
    $tele = $_POST['tele'];
    $newpassword = $_POST['newpassword'];
    $cpassword = $_POST['cpassword'];

    if ($newpassword == $cpassword) {
        $result = $database->query("select * from webuser where email='$email';");
        if ($result->num_rows == 1) {
            $error = '<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">Already have an account for this Email address.</label>';
        } else {
            $database->query("insert into patient(pemail, pname, ppassword, paddress, pregNo, pdob, ptel) values('$email', '$name', '$newpassword', '$address', '$regNo', '$dob', '$tele');");
            $database->query("insert into webuser(email, usertype) values('$email', 'p')");

            $_SESSION["user"] = $email;
            $_SESSION["usertype"] = "p";
            $_SESSION["username"] = $fname;

            header('Location: patient/index.php');
            $error = '<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;"></label>';
        }
    } else {
        $error = '<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">Password Confirmation Error! Reconfirm Password</label>';
    }
} else {
    $error = '<label for="promter" class="form-label"></label>';
}
?>



    <center>
    <div class="container">
        <table border="0" style="width: 69%;">
            <tr>
                <td colspan="2">
                    <p class="header-text">Let's Get Started</p>
                    <p class="sub-text">Now Create User Account.</p>
                </td>
            </tr>
            <tr>
                <form action="" method="POST">
                <td class="label-td" colspan="2">
                    <label for="newemail" class="form-label">Email: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <input type="email" name="newemail" class="input-text" placeholder="Email Address" required>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <label for="tele" class="form-label">Mobile Number: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <input type="tel" name="tele" class="input-text" placeholder="ex: 0712345678" pattern="[0]{1}[0-9]{9}" >
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <label for="newpassword" class="form-label">Create New Password: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <input type="password" id="newpassword" name="newpassword" class="input-text" placeholder="New Password" required>
                    <div class="strength">
                        <span></span>
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <p id="password-strength-text"></p>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <label for="cpassword" class="form-label">Confirm Password: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <input type="password" name="cpassword" class="input-text" placeholder="Confirm Password" required>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <?php echo $error ?>
                </td>
            </tr>
            <tr>
                <td>
                    <input type="reset" value="Reset" class="login-btn btn-primary-soft btn" >
                </td>
                <td>
                    <input type="submit" value="Sign Up" class="login-btn btn-primary btn">
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <br>
                    <label for="" class="sub-text" style="font-weight: 280;">Already have an account&#63; </label>
                    <a href="login.php" class="hover-link1 non-style-link">Login</a>
                    <br><br><br>
                </td>
            </tr>
                </form>
            </tr>
        </table>
    </div>
    </center>
<!-- password strength -->
    <script>
        const password = document.getElementById('newpassword');
        const strengthSpans = document.querySelectorAll('.strength span');
        const strengthText = document.getElementById('password-strength-text');

        password.addEventListener('input', () => {
            const value = password.value;
            const strength = getPasswordStrength(value);

            strengthSpans.forEach((span, index) => {
                if (index < strength.level) {
                    span.classList.add(strength.color);
                } else {
                    span.classList.remove('weak', 'medium', 'strong', 'very-strong');
                }
            });

            strengthText.textContent = strength.text;
        });

        function getPasswordStrength(password) {
            let strength = {
                level: 0,
                color: '',
                text: ''
            };

            if (password.length >= 8) strength.level++;
            if (/[A-Z]/.test(password)) strength.level++;
            if (/[0-9]/.test(password)) strength.level++;
            if (/[^A-Za-z0-9]/.test(password)) strength.level++;

            switch (strength.level) {
                case 0:
                    strength.color = '';
                    strength.text = '';
                    break;
                case 1:
                    strength.color = 'weak';
                    strength.text = 'Weak';
                    break;
                case 2:
                    strength.color = 'medium';
                    strength.text = 'Medium';
                    break;
                case 3:
                    strength.color = 'strong';
                    strength.text = 'Strong';
                    break;
                case 4:
                    strength.color = 'very-strong';
                    strength.text = 'Very Strong';
                    break;
            }

            return strength;
        }
    </script>
</body>
</html>
