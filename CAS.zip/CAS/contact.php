<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer-master/src/Exception.php';
require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';

$name_error = $email_error = $message_error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate name
    if (empty($_POST["name"])) {
        $name_error = "Name is required";
    } else {
        $name = test_input($_POST["name"]);
        // Check if name contains only letters and whitespace
        if (!preg_match("/^[a-zA-Z\s]+$/", $name)) {
            $name_error = "Only letters and white space allowed";
        }
    }

    if (empty($_POST["email"])) {
        $email_error = "Email is required";
    } else {
        $email = test_input($_POST["email"]);
        // Check if email address is well-formed
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $email_error = "Invalid email format";
        }
    }

    // Validate message
    if (empty($_POST["message"])) {
        $message_error = "Message is required";
    } else {
        $message = test_input($_POST["message"]);
    }

    if (empty($name_error) && empty($email_error) && empty($message_error)) {
        $mail = new PHPMailer(true);

        try {
            // SMTP configuration
            $mail->isSMTP();
            $mail->Host = "smtp.gmail.com";
            $mail->SMTPAuth = true;
            $mail->Username = "roszylynn05@gmail.com"; // your email address
            $mail->Password = "gjtg tchm soed zulm"; // app-specific password
            $mail->SMTPSecure = "ssl"; // secure transfer protocol to use
            $mail->Port = 465; // set the SMTP port

            // Sender and recipient
            $mail->setFrom("roszylynn05@gmail.com"); // your gmail
            $mail->addAddress("roszylynn05@gmail.com");

            // Email content
            $mail->isHTML(true);
            $mail->Subject = "Contact Form Submission";
            $mail->Body = "Sender's Email: " . $email . "<br><br>" . $message;

            if ($mail->send()) {
                echo "<script>
                        alert('Message Sent Successfully !');
                        document.location.href = 'contact.php';
                      </script>";
            } else {
                echo "<script>
                        alert('Message could not be sent.');
                        document.location.href = 'contact.php';
                      </script>";
            }
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    }
}

// Function to sanitize input data
function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CUEA COUNSELING</title>
    <link rel="stylesheet" href="css/contact.css">
    <link rel="stylesheet" href="css/home.css">
</head>
<body>
    <!-- Navbar section -->
    <nav class="navbar"> 
        <div class="navbar__container">
             <a href="home.html" id="navbar__logo">CUEA COUNSELING</a>
             <div class="navbar__toggle" id="mobile-menu">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
             </div>
             <ul class="navbar__menu">
                <li class="navbar__item">
                    <a href="home.html" class="navbar__links">Home</a>
                </li>
                <li class="navbar__item">
                    <a href="counselor.html" class="navbar__links">Counselor</a>
                </li>
                <li class="navbar__item">
                    <a href="services.html" class="navbar__links">Services</a>
                </li>
                <li class="navbar__item">
                    <a href="contact.php" class="navbar__links">Contact</a>
                </li>
                <li class="navbar__item dropdown">
                    <a href="how-it-works.html" class="navbar__links ">How It Works</a>
                </li>
                <li class="navbar__btn">
                    <a href="login.php" class="button">Login</a>
                </li>
                <li class="navbar__btn">
                    <a href="signup.php" class="button">Signup</a>
                </li>
             </ul>
        </div>
    </nav>
    
    <div class="banner-title">
        <h1></h1>
    </div>
    
    <div class="contact-wrap">
        <div class="contact-in">
            <h1>Contact Info</h1>
            <h2>Phone</h2>
            <p>0709691000 | 0709691008</p>
            <h2>Email</h2>
            <p>study@cuea.edu</p>
            <h2>Address</h2>
            <p> Bogani East Road, off Magadi Road, Next to Galleria Mall, 23km from the Jomo Kenyatta International Airport in Nairobi, Kenya.</p>
           
        </div>
        
        <div class="contact-in">
            <h1>How may we help you?</h1>
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <input type="text" name="name" placeholder="Full Name" class="contact-in-input" value="<?php echo isset($name) ? $name : ''; ?>">
                <div style="color: red;"><?php echo $name_error; ?></div>

                <input type="text" name="email" placeholder="Your Email" class="contact-in-input" value="<?php echo isset($email) ? $email : ''; ?>">
                <div style="color: red;"><?php echo $email_error; ?></div>

                <input type="text" name="subject" placeholder="Subject" class="contact-in-input">
                <div style="color: red;"><?php echo isset($subject_error) ? $subject_error : ''; ?></div>

                <textarea name="message" placeholder="Message" class="contact-in-textarea"><?php echo isset($message) ? $message : ''; ?></textarea>
                <div style="color: red;"><?php echo $message_error; ?></div>

                <input type="submit" value="SUBMIT" class="button">
            </form>
        </div>
        <div class="contact-in">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3988.7088231429643!2d36.754954814101495!3d-1.3512454360800046!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x182f0539d181204b%3A0x6e7169577881d08f!2sCatholic%20University%20of%20Eastern%20Africa!5e0!3m2!1sen!2ske!4v1627428260166!5m2!1sen!2ske" width="100%" height="auto" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
            </div>
</div>

<script src="app.js"></script>

</body>
<footer>
    <div class="footer-container">
        <div class="footer-links">
            <div class="footer-links-wrapper">
            <div class="footer-links-items">
            <h2>For More Information</h2>
                    <a href="home.html">About Us</a>
                    <a href="how-it-works.html">How It Works</a>
                   <a href="contact.php">Contact</a>
                </div>
                <div class="footer-links-items">
                    <h2>Connect with Us</h2>
                    <a href="https://www.instagram.com/cuea_official/">Instagram</a>
                    <a href="https://www.facebook.com/TheCatholicUniversityOfEasternAfricaCuea?ref=bookmarks">Facebook</a>
                    <a href="https://x.com/cuea_official">Twitter</a>
                </div>
            </div>
        </div>
        <div class="footer-logo">
            <a href="home.html" id="footer-logo">CUEA COUNSELING</a>
        </div>
        <p class="website-right">© CUEA COUNSELING 2023. All rights reserved.</p>
    </div>
</footer>

</html>
