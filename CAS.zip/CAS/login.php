<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/login1.css">
    <link rel="stylesheet" href="css/home.css">
    <title>LOGIN</title>
</head>
<body>
    <!-- Navbar section -->
    <nav class="navbar"> 
        <div class="navbar__container">
             <a href="home.html" id="navbar__logo">CUEA COUNSELING</a>
             <div class="navbar__toggle" id="mobile-menu">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
             </div>
             <ul class="navbar__menu">
                <li class="navbar__item">
                    <a href="home.html" class="navbar__links">Home</a>
                </li>
                <li class="navbar__item">
                    <a href="counselor.html" class="navbar__links">Counselor</a>
                </li>
                <li class="navbar__item">
                    <a href="services.html" class="navbar__links">Services</a>
                </li>
                <li class="navbar__item">
                    <a href="contact.php" class="navbar__links">Contact</a>
                </li>
                <li class="navbar__item dropdown">
                    <a href="how-it-works.html" class="navbar__links ">How It Works</a>
                </li>
                <li class="navbar__btn">
                    <a href="login.php" class="button">Login</a>
                </li>
                <li class="navbar__btn">
                    <a href="signup.php" class="button">Signup</a>
                </li>
             </ul>
        </div>
    </nav>
    <?php
session_start();
$_SESSION["user"] = "";
$_SESSION["usertype"] = "";
date_default_timezone_set('Africa/Nairobi');
$date = date('Y-m-d');
$_SESSION["date"] = $date;
include("connection.php");

$error = '<label for="promter" class="form-label">&nbsp;</label>';

if ($_POST) {
    $email = $_POST['useremail'];
    $password = $_POST['userpassword'];
    $error = '<label for="promter" class="form-label"></label>';

    $result = $database->query("SELECT * FROM webuser WHERE email='$email'");
    if ($result->num_rows == 1) {
        $utype = $result->fetch_assoc()['usertype'];
        $logMessage = '';
        if ($utype == 'p') {
            $checker = $database->query("SELECT * from patient WHERE pemail='$email' AND ppassword='$password'");
            if ($checker->num_rows == 1) {
                $_SESSION['user'] = $email;
                $_SESSION['usertype'] = 'p';
                $logMessage = "Patient login: $email at " . date('Y-m-d H:i:s');
                header('location: patient/index.php');
            } else {
                $error = '<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">Wrong credentials: Invalid email or password</label>';
            }
        } elseif ($utype == 'a') {
            $checker = $database->query("SELECT * from admin WHERE aemail='$email' AND apassword='$password'");
            if ($checker->num_rows == 1) {
                $_SESSION['user'] = $email;
                $_SESSION['usertype'] = 'a';
                $logMessage = "Admin login: $email at " . date('Y-m-d H:i:s');
                header('location: admin/index.php');
            } else {
                $error = '<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">Wrong credentials: Invalid email or password</label>';
            }
        } elseif ($utype == 'd') {
            $checker = $database->query("SELECT * from counselor WHERE lpcemail='$email' AND lpcpassword='$password'");
            if ($checker->num_rows == 1) {
                $_SESSION['user'] = $email;
                $_SESSION['usertype'] = 'd';
                $logMessage = "Counselor login: $email at " . date('Y-m-d H:i:s');
                header('location: counselor/index.php');
            } else {
                $error = '<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">Wrong credentials: Invalid email or password</label>';
            }
        }

        // Log the login attempt
        if ($logMessage !== '') {
            $logFile = fopen('login_log.txt', 'a');
            fwrite($logFile, $logMessage . "\n");
            fclose($logFile);
        }
    } else {
        $error = '<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">We can\'t find any account for this email.</label>';
    }
}
?>


    <center>
    <div class="container">
        <table border="0" style="margin: 0;padding: 0;width: 60%;" >
            <tr>
                <td>
                    <p class="header-text">Welcome Back!</p>
                </td>
            </tr>
            <div class="form-body">
                <tr>
                    <td>
                        <p class="sub-text">Login with your details to continue</p>
                    </td>
                </tr>
                <tr>
                    <form id="loginForm" action="" method="POST">
                    <td class="label-td">
                        <label for="useremail" class="form-label">Email: </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td">
                        <input type="email" id="useremail" name="useremail" class="input-text" placeholder="Email Address" >
                    </td>
                </tr>
                <tr>
                    <td class="label-td">
                        <label for="userpassword" class="form-label">Password: </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td">
                        <input type="password" id="userpassword" name="userpassword" class="input-text" placeholder="Password" >
                    </td>
                </tr>
                <tr>
                    <td><br>
                    <?php echo $error ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="submit" value="Login" class="login-btn btn-primary btn">
                    </td>
                </tr>
                
            </div>
            <tr>
                    <td>
                        <br>
                        <a href="forgot_password.php" class="hover-link1 non-style-link">Forgot Password?</a>
                        <br><br><br>
                    </td>
                </tr>
            <tr>
                <td>
                    <br>
                    <label for="" class="sub-text" style="font-weight: 280;">New to CUEA COUNSELING?&#63; </label>
                    <a href="signup.php" class="hover-link1 non-style-link">Sign Up </a>
                    <br><br><br>
                </td>
            </tr>
            </form>
        </table>
    </div>
    </center>
    <footer>
        <div class="footer-container">
            <div class="footer-links">
                <div class="footer-links-wrapper">
                <div class="footer-links-items">
                <h2>For More Information</h2>
                    <a href="home.html">About Us</a>
                    <a href="how-it-works.html">How It Works</a>
                   <a href="contact.php">Contact</a>
                </div>
                <div class="footer-links-items">
                    <h2>Connect with Us</h2>
                    <a href="https://www.instagram.com/cuea_official/">Instagram</a>
                    <a href="https://www.facebook.com/TheCatholicUniversityOfEasternAfricaCuea?ref=bookmarks">Facebook</a>
                    <a href="https://x.com/cuea_official">Twitter</a>
                </div>
                </div>
            </div>
            <div class="footer-logo">
                <a href="home.html" id="footer-logo">CUEA COUNSELING</a>
            </div>
            <p class="website-right">© CUEA COUNSELING 2023. All rights reserved.</p>
        </div>
    </footer>
    <script>
        document.getElementById('loginForm').addEventListener('submit', function(event) {
            var email = document.getElementById('useremail').value;
            var password = document.getElementById('userpassword').value;
            var errorMessage = '';

            if (email === '') {
                errorMessage += 'Email is required. ';
            }
            if (password === '') {
                errorMessage += 'Password is required. ';
            }

            if (errorMessage !== '') {
                event.preventDefault();
                alert(errorMessage);
            }
        });
    </script>
     <script src="app.js"></script>
</body>
</html>
