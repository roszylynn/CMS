<?php
include("connection.php");

if ($_GET) {
    $token = $_GET['token'];

    $result = $database->query("SELECT * FROM webuser WHERE reset_token='$token'");
    if ($result->num_rows == 1) {
        // Display reset form
        if ($_POST) {
            $new_password = $_POST['new_password'];
            $confirm_password = $_POST['confirm_password'];

            if ($new_password === $confirm_password) {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $database->query("UPDATE webuser SET password='$hashed_password', reset_token=NULL WHERE reset_token='$token'");
                $message = "Your password has been successfully reset.";
            } else {
                $error = "Passwords do not match.";
            }
        }
    } else {
        $error = "Invalid or expired token.";
    }
} else {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/login1.css">
    <title>Reset Password</title>
</head>
<body>
    <center>
    <div class="container">
        <table border="0" style="margin: 0;padding: 0;width: 60%;" >
            <tr>
                <td>
                    <p class="header-text">Reset Password</p>
                </td>
            </tr>
            <div class="form-body">
                <tr>
                    <td>
                        <p class="sub-text">Enter your new password</p>
                    </td>
                </tr>
                <tr>
                    <form action="" method="POST">
                    <td class="label-td">
                        <label for="new_password" class="form-label">New Password: </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td">
                        <input type="password" id="new_password" name="new_password" class="input-text" placeholder="New Password" required>
                    </td>
                </tr>
                <tr>
                    <td class="label-td">
                        <label for="confirm_password" class="form-label">Confirm Password: </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td">
                        <input type="password" id="confirm_password" name="confirm_password" class="input-text" placeholder="Confirm Password" required>
                    </td>
                </tr>
                <tr>
                    <td><br>
                    <?php if (isset($error)) { echo '<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">' . $error . '</label>'; } ?>
                    <?php if (isset($message)) { echo '<label for="promter" class="form-label" style="color:rgb(60, 179, 113);text-align:center;">' . $message . '</label>'; } ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="submit" value="Reset Password" class="login-btn btn-primary btn">
                    </td>
                </tr>
                </form>
            </div>
        </table>
    </div>
    </center>
</body>
</html>
