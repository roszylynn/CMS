<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/adminmain.css">  
  
        
    <title>Appointments</title>
    <style>
        .popup{
            animation: transitionIn-Y-bottom 0.5s;
        }
        .sub-table{
            animation: transitionIn-Y-bottom 0.5s;
        }
    </style>
    <script>
        function printReport() {
            window.print();
        }
    </script>
</head>
<body>
    <?php

    //learn from w3schools.com

    session_start();

    if(isset($_SESSION["user"])){
        if(($_SESSION["user"])=="" or $_SESSION['usertype']!='a'){
            header("location: ../login.php");
        }

    }else{
        header("location: ../login.php");
    }
    
    

    //import database
    include("../connection.php");

    
    ?>
    <div class="container">
        <div class="menu">
            <table class="menu-container" border="0">
                <tr>
                    <td style="padding:10px" colspan="2">
                        <table border="0" class="profile-container">
                            <tr>
                                <td width="30%" style="padding-left:20px" >
                                    <img src="../img/user.png" alt="" width="100%" style="border-radius:50%">
                                </td>
                                <td style="padding:0px;margin:0px;">
                                    <p class="profile-title">Administrator</p>
                                    <p class="profile-subtitle">admin@elpc.com</p>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <a href="../logout.php" ><input type="button" value="Log out" class="logout-btn btn-primary-soft btn"></a>
                                </td>
                            </tr>
                    </table>
                    </td>
                
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-dashbord" >
                        <a href="index.php" class="non-style-link-menu"><div><p class="menu-text">Dashboard</p></a></div></a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-counselor ">
                        <a href="counselors.php" class="non-style-link-menu "><div><p class="menu-text">counselors</p></a></div>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-schedule ">
                        <a href="schedule.php" class="non-style-link-menu"><div><p class="menu-text">Schedule</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-appoinment menu-active menu-icon-appoinment-active">
                        <a href="appointment.php" class="non-style-link-menu non-style-link-menu-active"><div><p class="menu-text">Appointment</p></a></div>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-patient">
                        <a href="patient.php" class="non-style-link-menu"><div><p class="menu-text">Patients</p></a></div>
                    </td>
                </tr>

            </table>
        </div>
        <div class="dash-body">
            <table border="0" width="100%" style=" border-spacing: 0;margin:0;padding:0;margin-top:25px; ">
                <tr >
                    <td width="13%" >
                    <a href="appointment.php" ><button  class="login-btn btn-primary-soft btn btn-icon-back"  style="padding-top:11px;padding-bottom:11px;margin-left:20px;width:125px"><font class="tn-in-text">Back</font></button></a>
                    </td>
                    <td>
                        <p style="font-size: 23px;padding-left:12px;font-weight: 600;">Appointment Manager</p>
                                           
                    </td>
                    <td width="15%">
                    <p style="font-size: 20px;color: #000000;padding: 0;margin: 0;text-align: right;">
                        Today's Date
                    </p>
                    <p class="heading-sub12" style="color: #000000; padding: 0;margin: 0;text-align: right;">
                        <?php
                        date_default_timezone_set('Africa/Nairobi');
                        $today = date('d-m-Y');
                        echo $today;

                        $list110 = $database->query("select  * from  appointment;");

                        ?>
                        </p>
                    </td>
                    <td width="10%">
    <button onclick="printReport()" class="login-btn btn-primary-soft btn btn-icon-back" style="padding-top:11px;padding-bottom:11px;margin-left:20px;width:150px"><font class="tn-in-text">Print Report</font></button>
</td>
<script>
    function printReport() {
        window.print();
    }
</script>
<style>
    @media print {
        /* Hide menu and other non-essential elements */
        .menu, .logout-btn {
            display: none;
        }
        
        /* Adjust styling for printing */
        .container {
            width: 100%;
            margin: 0;
            padding: 0;
        }

        /* Additional styling for better print layout */
        /* Adjust as needed */
        .dash-body {
            padding-top: 0;
            margin-top: 0;
        }
    }
</style>


                </tr>
               
                <!-- <tr>
                    <td colspan="4" >
                        <div style="display: flex;margin-top: 40px;">
                        <div class="heading-main12" style="margin-left: 45px;font-size:20px;color:rgb(49, 49, 49);margin-top: 5px;">Schedule a Session</div>
                        <a href="?action=add-session&id=none&error=0" class="non-style-link"><button  class="login-btn btn-primary btn button-icon"  style="margin-left:25px;);">Add a Session</font></button>
                        </a>
                        </div>
                    </td>
                </tr> -->
                <tr>
                    <td colspan="4" style="padding-top:10px;width: 100%;" >
                    
                        <p class="heading-main12" style="margin-left: 45px;font-size:18px;color:rgb(49, 49, 49)">All Appointments (<?php echo $list110->num_rows; ?>)</p>
                    </td>
                    
                </tr>
                <tr>
                    <td colspan="4" style="padding-top:0px;width: 100%;" >
                        <center>
                        <table class="filter-container" border="0" >
                        <tr>
                           <td width="10%">

                           </td> 
                        <td width="5%" style="text-align: center;">
                        Date:
                        </td>
                        <td width="30%">
                        <form action="" method="post">
                            
                            <input type="date" name="sheduledate" id="date" class="input-text filter-container-items" style="margin: 0;width: 95%;">

                        </td>
                        <td width="5%" style="text-align: center;">
                        counselor:
                        </td>
                        <td width="30%">
                        <select name="lpcid" id="" class="box filter-container-items" style="width:90% ;height: 37px;margin: 0;" >
                            <option value="" disabled selected hidden>Choose counselor Name from the list</option><br/>
                                
                            <?php 
                             
                                $list11 = $database->query("select  * from  counselor order by lpcname asc;");

                                for ($y=0;$y<$list11->num_rows;$y++){
                                    $row00=$list11->fetch_assoc();
                                    $sn=$row00["lpcname"];
                                    $id00=$row00["lpcid"];
                                    echo "<option value=".$id00.">$sn</option><br/>";
                                };


                                ?>

                        </select>
                    </td>
                    <td width="12%">
                        <input type="submit"  name="filter" value=" Filter" class=" btn-primary-soft btn button-icon btn-filter"  style="padding: 15px; margin :0;width:100%">
                        </form>
                    </td>

                    </tr>
                            </table>

                        </center>
                    </td>
                    
                </tr>
                
                <?php
                    if($_POST){
                        //print_r($_POST);
                        $sqlpt1="";
                        if(!empty($_POST["sheduledate"])){
                            $sheduledate=$_POST["sheduledate"];
                            $sqlpt1=" schedule.scheduledate='$sheduledate' ";
                        }


                        $sqlpt2="";
                        if(!empty($_POST["lpcid"])){
                            $lpcid=$_POST["lpcid"];
                            $sqlpt2=" counselor.lpcid=$lpcid ";
                        }
                        //echo $sqlpt2;
                        //echo $sqlpt1;
                        $sqlmain= "select appointment.appoid,schedule.scheduleid,schedule.title,counselor.lpcname,patient.pname,schedule.scheduledate,schedule.scheduletime,appointment.apponum,appointment.appodate from schedule inner join appointment on schedule.scheduleid=appointment.scheduleid inner join patient on patient.pid=appointment.pid inner join counselor on schedule.lpcid=counselor.lpcid";
                        $sqllist=array($sqlpt1,$sqlpt2);
                        $sqlkeywords=array(" where "," and ");
                        $key2=0;
                        foreach($sqllist as $key){
                            if(!empty($key)){
                                $sqlmain.=$sqlkeywords[$key2].$key;
                                $key2++;
                            };
                        };
                        
                        
                        
                        
                        //echo $sqlmain;

                        
                        
                    }else{
                        $sqlmain= "select appointment.appoid,schedule.scheduleid,schedule.title,counselor.lpcname,patient.pname,schedule.scheduledate,schedule.scheduletime,appointment.apponum,appointment.appodate from schedule inner join appointment on schedule.scheduleid=appointment.scheduleid inner join patient on patient.pid=appointment.pid inner join counselor on schedule.lpcid=counselor.lpcid  order by schedule.scheduledate asc";

                    }



                ?>

                <tr>
                    <td colspan="4" >
                        <center>
                        <div class="abc scroll" style="height: 600px;" >
                        <table width="93%" class="sub-table scrolldown" border="0" >
                        <thead>
                        <tr>
                                <th class="table-headin">
                                    
                                
                                Appointment number
                                
                                </th>
                                
                                <th class="table-headin">
                                    Session Title
                                </th>
                                <th class="table-headin">
                                    
                                    counselor
                                    
                                </th>
                                <th class="table-headin">
                                    
                                    Patient
                                    
                                </th>
                                <th class="table-headin">
                                    
                                Session Date & Time
                                    
                                </th>
                                <th class="table-headin">
                                    
                                Appointment Date
                                    
                                </th>
                                
                                <th class="table-headin">
                                    
                                    Events
                                    
                                </tr>
                        </thead>
                        <tbody>
                        
                            <?php
                                
                                
                                

                                $result= $database->query($sqlmain);

                                if($result->num_rows==0){
                                    echo '<tr>
                                    <td colspan="7">
                                    <br><br><br><br>
                                    <center>
                                    
                                    
                                    <p class="heading-main12" style="margin-left: 45px;font-size:25px;color:rgb(49, 49, 49)">We couldnt find anything related to your keywords !</p>
                                    <a class="non-style-link" href="appointment.php"><button  class="login-btn btn-primary-soft btn"  style="display: flex;justify-content: center;align-items: center;margin-left:20px;">&nbsp; Show all Appointments &nbsp;</font></button>
                                    </a>
                                    </center>
                                    <br><br><br><br>
                                    </td>
                                    </tr>';
                                    
                                }else{
                                    for ( $x=0; $x<$result->num_rows;$x++){
                                        $row=$result->fetch_assoc();
                                        $appoid=$row["appoid"];
                                        $scheduleid=$row["scheduleid"];
                                        $title=$row["title"];
                                        $counselorname=$row["lpcname"];
                                        $scheduletime=$row["scheduletime"];
                                        $scheduledate=$row["scheduledate"];
                                        $pname=$row["pname"];
                                        $apponum=$row["apponum"];
                                        $appodate=$row["appodate"];
                                        echo '<tr >
                                            <td style="font-weight:600;"> &nbsp;'.
                                            
                                            $apponum
                                            .'</td >
                                            
                                            <td style="text-align:center;">
                                            '.substr($title,0,30).'
                                            </td>
                                            <td>
                                            '.substr($counselorname,0,20).'
                                            </td>
                                            <td>
                                                '.substr($pname,0,20).'
                                            </td>
                                            <td style="text-align:center;">
                                                '.substr($scheduledate,0,10).' '.substr($scheduletime,0,5).'
                                            </td>
                                            <td style="text-align:center;">
                                            '.$appodate.'
                                            </td>

                                        <td>
                                        <div style="display:flex;justify-content: center;">
                                        
                                        <!--<a href="?action=view&id='.$appoid.'" class="non-style-link"><button  class="btn-primary-soft btn button-icon btn-view"  style="padding: 12px 40px;margin-top: 10px;"><font class="tn-in-text">View</font></button></a>
                                        &nbsp;&nbsp;&nbsp;-->
                                        <a href="?action=drop&id='.$appoid.'&title='.$title.'&name='.$pname.'" class="non-style-link"><button  class="btn-primary-soft btn button-icon btn-delete"  style="padding: 12px 40px;margin-top: 10px;"><font class="tn-in-text">Cancel</font></button></a>
                                        </div>
                                        </td>
                                        </tr>';

                                        
                                        

                                    }
                                }

                            ?>
                            
                            </tbody>

                        </table>
                        </div>
                        </center>
                    </td>
                    
                </tr>
                
            </table>
        </div>
    </div>
    <?php

    if($_GET){
        $id=$_GET["id"];
        $action=$_GET["action"];
        if($action=='add-session'){
            echo '
            <div id="popup1" class="overlay">
                    <div class="popup">
                    <center>
                        <a class="close" href="schedule.php">&times;</a> 
                        <div style="display: flex;justify-content: center;">
                        <div class="abc">
                        <form action="add-session.php" method="POST" class="add-new-form">
                            <table width="80%" class="sub-table scrolldown add-new-form-container" border="0">
                            <tr>
                                    <td class="label-td" colspan="2">'.
                                    
                                    '</td>
                                </tr>
                                <tr>
                                    <td class="label-td" colspan="2">
                                        <p class="sub-text">Add New Session</p>
                                    </td>
                                </tr>
                                
                                <tr>
                                    <td class="label-td" colspan="2">'.
                                    
                                        '</td>
                                </tr>
                                <tr>
                                    <td class="label-td">
                                        <label for="title" class="form-label">Session Title: </label>
                                    </td>
                                    <td class="label-td">
                                        <input type="text" name="title" class="input-text" placeholder="Name of this Session" required>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="label-td">
                                        <label for="title" class="form-label">counselor: </label>
                                    </td>
                                    <td class="label-td">
                                        <select name="lpcid" id="" class="box">';
                                            
                                            $list11 = $database->query("select  * from  counselor order by lpcname asc;");
    
                                            for ($y=0;$y<$list11->num_rows;$y++){
                                                $row00=$list11->fetch_assoc();
                                                $sn=$row00["lpcname"];
                                                $id00=$row00["lpcid"];
                                                echo "<option value=".$id00.">$sn</option><br/>";
                                            };


                                  echo '       </select>
                                    
                                    </td>
                                </tr>

                                <tr>
                                    <td class="label-td">
                                        <label for="title" class="form-label">Date: </label>
                                    </td>
                                    <td class="label-td">
                                        <input type="date" name="date" class="input-text" min="'.date('Y-m-d').'" required>
                                    </td>
                                </tr>

                                <tr>
                                    <td class="label-td">
                                        <label for="title" class="form-label">Time: </label>
                                    </td>
                                    <td class="label-td">
                                        <input type="time" name="time" class="input-text" placeholder="Time" required>
                                    </td>
                                </tr>
                                
                                <tr>
                                    <td colspan="2">
                                        <input type="reset" value="Reset" class="login-btn btn-primary-soft btn">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <input type="submit" value="Add" class="login-btn btn-primary btn">
                                    </td>

                                </tr>
                                </tr>
                                
                            </table>
                    </div>
                    </div>
                    </center>
                    <br><br>
            </div>
            ';
        }elseif($action=='session-added'){
            $titleget=$_GET["title"];
            echo '
            <div id="popup1" class="overlay">
                    <div class="popup">
                    <center>
                        <h2>Session Placed.</h2>
                        <a class="close" href="schedule.php">&times;</a>
                        <div class="content">
                        '.substr($titleget,0,40).' was scheduled.<br><br>
                            
                        </div>
                        <div style="display: flex;justify-content: center;">
                        
                        <a href="schedule.php" class="non-style-link"><button  class="btn-primary btn" style="display: flex;justify-content: center;align-items: center;margin:10px;padding:10px;">OK</button></a>
                        <a href="schedule.php" class="non-style-link"></a>
                        
                        </div>
                        
                    </center>
            </div>
            </div>
            ';
        }elseif($action=='drop'){
            $titleget=$_GET["title"];
            $nameget=$_GET["name"];
            echo '
            <div id="popup1" class="overlay">
                    <div class="popup">
                    <center>
                        <h2>Are you sure?</h2>
                        <a class="close" href="appointment.php">&times;</a>
                        <div class="content">
                            You want to cancel this appointment?<br><br>
                            Session Name: &nbsp;<b>'.substr($titleget,0,40).'</b><br>
                            Patient Name: &nbsp;<b>'.substr($nameget,0,40).'</b><br><br>
                            
                        </div>
                        <div style="display: flex;justify-content: center;">
                        <a href="delete-appointment.php?id='.$id.'" class="non-style-link"><button  class="btn-primary btn" style="display: flex;justify-content: center;align-items: center;margin:10px;padding:10px;">Yes</button></a>&nbsp;&nbsp;&nbsp;
                        <a href="appointment.php" class="non-style-link"><button  class="btn-primary-soft btn" style="display: flex;justify-content: center;align-items: center;margin:10px;padding:10px;">No</button></a>

                        </div>
                    </center>
            </div>
            </div>
            '; 
    }elseif($action=='view'){
        $sqlmain= "select * from counselor where lpcid='$id'";
        $result= $database->query($sqlmain);
        $row=$result->fetch_assoc();
        $name=$row["lpcname"];
        $email=$row["lpcemail"];
        $spe=$row["specialties"];
        $lqualification=$row["qualification"];
        $tele=$row['lpctel'];
        
        echo '
        <div id="popup1" class="overlay">
                <div class="popup">
                <center>
                    <h2>View Details</h2>
                    <a class="close" href="counselor.php">&times;</a>
                    <div class="content">
                        Metro Health Management System<br>
                        
                    </div>
                    <div style="display: flex;justify-content: center;">
                    
                    <table width="80%" class="sub-table scrolldown add-new-form-container" border="0">
                    
                        <tr>
                            <td>
                                <p style="text-align: left;padding: 0;margin: 0;">Name: </p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                '.$name.'<br><br>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p style="text-align: left;padding: 0;margin: 0;">Email: </p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                '.$email.'<br><br>
                            </td>
                        </tr>
                        <tr>
                        <td>
                            <p style="text-align: left;padding: 0;margin: 0;">Telephone: </p>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            '.$tele.'<br><br>
                        </td>
                    </tr>
                        <tr>
                            <td>
                                <p style="text-align: left;padding: 0;margin: 0;">Specialties: </p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                '.$spe.'<br><br>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p style="text-align: left;padding: 0;margin: 0;">Qualification: </p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                '.$lqualification.'<br><br>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <a href="counselor.php"><input type="button" value="OK" class="login-btn btn-primary-soft btn"></a>
                            
                            </td>
            
                        </tr>
                    </table>
                    </div>
                </center>
        </div>
        </div>
        ';
    }

}
        
    ?>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const dateInput = document.getElementById('date');
        const timeInput = document.getElementById('time');

        dateInput.addEventListener('change', function() {
            if (dateInput.value) {
                timeInput.removeAttribute('disabled');
            } else {
                timeInput.setAttribute('disabled', 'disabled');
            }
        });
    });
</script>




</body>
</html>
