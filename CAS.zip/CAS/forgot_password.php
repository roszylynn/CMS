<?php
$error = ''; // Define $error variable initially without HTML tags

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer-master/src/Exception.php';
require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';


if ($_POST) {
    include("connection.php");

    $email = $_POST['useremail'];

    // Check if email exists in the database
    $result = $database->query("SELECT * FROM webuser WHERE email='$email'");
    if ($result->num_rows == 1) {
        // Generate a password reset token
        $token = bin2hex(random_bytes(50));
        $database->query("UPDATE webuser SET reset_token='$token' WHERE email='$email'");

        // Send the reset link via email
        $resetLink = "http://yourwebsite.com/reset_password.php?token=$token";
        $subject = "Password Reset Request";
        $message = "Click on the following link to reset your password: $resetLink";

        // PHPMailer configuration
        $mail = new PHPMailer(true);
        try {
            //Server settings
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'roszylynn05@gmail.com'; // Your Gmail address
            $mail->Password   = 'kvjc dmrc hpnw xhtp'; // Your Gmail password or app password
            $mail->SMTPSecure = 'tls';
            $mail->Port       = 587;

            //Recipients
            $mail->setFrom('no-reply@yourwebsite.com', 'Your Website');
            $mail->addAddress($email);

            // Content
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body    = $message;

            $mail->send();
            $error = '<label for="promter" class="form-label" style="color:rgb(60, 179, 113);text-align:center;">A password reset link has been sent to your email.</label>';
        } catch (Exception $e) {
            $error = '<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">Failed to send the email. Please try again later.</label>';
        }
    } else {
        $error = '<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">We can\'t find any account with this email.</label>';
    }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/login1.css">
    <title>Forgot Password</title>
</head>
<body>
    <center>
    <div class="container">
        <table border="0" style="margin: 0;padding: 0;width: 60%;" >
            <tr>
                <td>
                    <p class="header-text">Forgot Password</p>
                </td>
            </tr>
            <div class="form-body">
                <tr>
                    <td>
                        <p class="sub-text">Enter your email to reset your password</p>
                    </td>
                </tr>
                <tr>
                    <form action="forgot_password.php" method="POST">
                    <td class="label-td">
                        <label for="useremail" class="form-label">Email: </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td">
                        <input type="email" id="useremail" name="useremail" class="input-text" placeholder="Email Address" required>
                    </td>
                </tr>
                <tr>
                    <td><br>
                    <?php echo $error ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="submit" value="Submit" class="login-btn btn-primary btn">
                    </td>
                    
                </tr>
                <tr>
                <td>
                    <br>
                    <label for="" class="sub-text" style="font-weight: 280;">or Try Another way&#63; </label>
                    <a href="contact.php" class="hover-link1 non-style-link">Send Us A Message </a>
                    <br><br><br>
                </td>
            </tr>
                
                </form>
            </div>
        </table>
    </div>
    </center>
</body>
</html>
