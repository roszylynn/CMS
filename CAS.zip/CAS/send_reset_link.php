<?php
session_start();
include("connection.php");

if ($_POST) {
    $email = $_POST['useremail'];
    $result = $database->query("SELECT * FROM webuser WHERE email='$email'");
    if ($result->num_rows == 1) {
        // Generate a unique reset token
        $token = bin2hex(random_bytes(50));

        // Store the token in the database with an expiration time
        $database->query("UPDATE webuser SET reset_token='$token', token_expiry=DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE email='$email'");

        // Send the email with the reset link
        $resetLink = "http://yourdomain.com/reset_password.php?token=$token";
        $subject = "Password Reset Request";
        $message = "Click the link below to reset your password: \n\n $resetLink";
        $headers = "From: no-reply@yourdomain.com";

        if (mail($email, $subject, $message, $headers)) {
            echo "A password reset link has been sent to your email.";
        } else {
            echo "Failed to send the password reset link.";
        }
    } else {
        echo "No account found with that email address.";
    }
} else {
    header("Location: forgot_password.php");
    exit();
}
?>
