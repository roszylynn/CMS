-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2024 at 01:47 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aemail` varchar(255) NOT NULL,
  `apassword` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aemail`, `apassword`) VALUES
('admin@cuea.edu', '123');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `appoid` int(11) NOT NULL,
  `pid` int(10) DEFAULT NULL,
  `apponum` int(3) DEFAULT NULL,
  `scheduleid` int(10) DEFAULT NULL,
  `appodate` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`appoid`, `pid`, `apponum`, `scheduleid`, `appodate`) VALUES
(1, 1, 1, 1, '2022-06-03'),
(2, 4, 1, 9, '2024-05-15'),
(3, 5, 2, 9, '2024-05-15'),
(4, 6, 3, 9, '2024-05-15'),
(6, 9, 2, 1, '2024-05-16'),
(7, 10, 1, 15, '2024-05-19'),
(8, 10, 1, 14, '2024-05-19'),
(9, 3, 1, 10, '2024-05-23');

-- --------------------------------------------------------

--
-- Table structure for table `counselor`
--

CREATE TABLE `counselor` (
  `lpcid` int(11) NOT NULL,
  `lpcemail` varchar(255) DEFAULT NULL,
  `lpcname` varchar(255) DEFAULT NULL,
  `lpcpassword` varchar(255) DEFAULT NULL,
  `lpcregNo` varchar(15) DEFAULT NULL,
  `lpctel` varchar(15) DEFAULT NULL,
  `specialties` int(2) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `counselor`
--

INSERT INTO `counselor` (`lpcid`, `lpcemail`, `lpcname`, `lpcpassword`, `lpcregNo`, `lpctel`, `specialties`) VALUES
(1, 'tonyonum@gmail.com', 'Tony Onum', 'tonyonum', '1024653', '0704637383', 1),
(2, 'annaalache@cuea.edu', 'Anna alache', 'annaalache', '1946372', '0708367283', 6),
(3, 'roszylynn05@cuea.edu', 'Roseline Ogiri', 'roszy', '1042720', '0708470191', 8),
(4, 'Dorothy@cuea.edu', 'Dorothy adda', 'dorothy', '1234545', '0794343273', 4),
(5, 'david@cuea.edu', 'David Ola', 'david', '1032436', '0902327833', 2),
(6, 'councelor@cuea.edu', 'Counselor', 'test', '1024653', '0708470191', 2);

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `pid` int(11) NOT NULL,
  `pemail` varchar(255) DEFAULT NULL,
  `pname` varchar(255) DEFAULT NULL,
  `ppassword` varchar(255) DEFAULT NULL,
  `paddress` varchar(255) DEFAULT NULL,
  `pregNo` varchar(15) DEFAULT NULL,
  `pdob` date DEFAULT NULL,
  `ptel` varchar(15) DEFAULT NULL,
  `pgender` varchar(10) DEFAULT NULL,
  `prole` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`pid`, `pemail`, `pname`, `ppassword`, `paddress`, `pregNo`, `pdob`, `ptel`, `pgender`, `prole`) VALUES
(1, 'graceoche@gmail.com', 'Grace Oche', 'graceoche', 'Nairobi', '0000000000', '2000-01-01', '0703452635', '0', NULL),
(10, 'debby@cuea.edu', 'debby kigen', 'debby', 'kitengela', '', '2006-04-24', '0701232323', NULL, NULL),
(3, 'roseonum@cuea.edu', 'rose onum', 'roseonum', 'lrc', '9874563', '2024-05-23', '0712345678', '0', NULL),
(11, 'patient@cuea.edu', 'new  patient', 'test', 'test', '', '2006-03-29', '0712345678', NULL, NULL),
(9, 'john@gmail.com', 'john keith', 'john', 'Catholic university of eastern Africa, Nairobi, Kenya', '', '2024-05-15', '0712345678', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `scheduleid` int(11) NOT NULL,
  `lpcid` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `scheduledate` date DEFAULT NULL,
  `scheduletime` time DEFAULT NULL,
  `nop` int(4) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`scheduleid`, `lpcid`, `title`, `scheduledate`, `scheduletime`, `nop`) VALUES
(14, '1', 'general', '2024-05-29', '15:40:00', 1),
(13, '3', 'general', '2024-05-31', '10:40:00', 3),
(12, '4', 'Grief', '2024-05-30', '17:05:00', 2),
(11, '5', 'peace', '2024-05-28', '15:00:00', 1),
(10, '2', 'General', '2024-05-26', '12:30:00', 2),
(15, '4', 'general', '2024-05-29', '14:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `specialties`
--

CREATE TABLE `specialties` (
  `id` int(2) NOT NULL,
  `sname` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `specialties`
--

INSERT INTO `specialties` (`id`, `sname`) VALUES
(1, 'Adventure Retreats'),
(2, 'Art Therapy Sessions'),
(3, 'Community Engagement '),
(4, 'Creative Expression Classes'),
(5, 'Health & Nutrition Consultation '),
(6, 'Life Coaching'),
(7, 'Mindfulness Workshops'),
(8, 'Personal Development'),
(9, 'Relationship Counseling '),
(10, 'Wellness Sessions');

-- --------------------------------------------------------

--
-- Table structure for table `webuser`
--

CREATE TABLE `webuser` (
  `email` varchar(255) NOT NULL,
  `usertype` char(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `webuser`
--

INSERT INTO `webuser` (`email`, `usertype`) VALUES
('admin@cuea.edu', 'a'),
('tonyonum@gmail.com', 'd'),
('graceoche@gmail.com', 'p'),
('debby@cuea.edu', 'p'),
('roseonum@cuea.edu', 'p'),
('councelor@cuea.edu', 'd'),
('patient@cuea.edu', 'p'),
('john@gmail.com', 'p'),
('annaalache@cuea.edu', 'd'),
('roszylynn05@cuea.edu', 'd'),
('dorothy@cuea.edu', 'd'),
('david@cuea.edu', 'd');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aemail`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`appoid`),
  ADD KEY `pid` (`pid`),
  ADD KEY `scheduleid` (`scheduleid`);

--
-- Indexes for table `counselor`
--
ALTER TABLE `counselor`
  ADD PRIMARY KEY (`lpcid`),
  ADD KEY `specialties` (`specialties`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`scheduleid`),
  ADD KEY `docid` (`lpcid`);

--
-- Indexes for table `specialties`
--
ALTER TABLE `specialties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `webuser`
--
ALTER TABLE `webuser`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `appoid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `counselor`
--
ALTER TABLE `counselor`
  MODIFY `lpcid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `scheduleid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
