<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/animations.css">  
    <link rel="stylesheet" href="css/signup1.css">
    <link rel="stylesheet" href="css/home.css">
    <title>Sign Up</title>
    <style>
        .error {
            color: rgb(255, 62, 62);
            text-align: center;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <!-- Navbar section -->
    <nav class="navbar"> 
        <div class="navbar__container">
             <a href="home.html" id="navbar__logo">CUEA COUNSELING</a>
             <div class="navbar__toggle" id="mobile-menu">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
             </div>
             <ul class="navbar__menu">
                <li class="navbar__item">
                    <a href="home.html" class="navbar__links">Home</a>
                </li>
                <li class="navbar__item">
                    <a href="counselor.html" class="navbar__links">Counselor</a>
                </li>
                <li class="navbar__item">
                    <a href="services.html" class="navbar__links">Services</a>
                </li>
                <li class="navbar__item">
                    <a href="contact.php" class="navbar__links">Contact</a>
                </li>
                <li class="navbar__item dropdown">
                    <a href="how-it-works.html" class="navbar__links ">How It Works</a>
                </li>
                <li class="navbar__btn">
                    <a href="login.php" class="button">Login</a>
                </li>
                <li class="navbar__btn">
                    <a href="signup.php" class="button">Signup</a>
                </li>
             </ul>
        </div>
    </nav>

    <?php
    session_start();
    $_SESSION["user"] = "";
    $_SESSION["usertype"] = "";
    date_default_timezone_set('Africa/Nairobi');
    $date = date('Y-m-d');
    $_SESSION["date"] = $date;

    if ($_POST) {
        $_SESSION["personal"] = array(
            'fname' => $_POST['fname'],
            'lname' => $_POST['lname'],
            'address' => $_POST['address'],
            'reg' => $_POST['regNo'],
            'dob' => $_POST['dob'],
            'gender' => $_POST['gender'],
            'role' => $_POST['role']
        );
        header("location: create-account.php");
    }
    ?>
    <center>
    <div class="container">
        <table border="0">
            <tr>
                <td colspan="2">
                    <p class="header-text">Let's Get Started</p>
                    <p class="sub-text">Add Your Personal Details to Continue</p>
                </td>
            </tr>
            <tr>
                <form id="signupForm" action="" method="POST" onsubmit="return validateForm()">
                <td class="label-td" colspan="2">
                    <label for="name" class="form-label">Name: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td">
                    <input type="text" name="fname" class="input-text" placeholder="First Name" required pattern="[A-Za-z]+" title="First name should contain letters only.">
                </td>
                <td class="label-td">
                    <input type="text" name="lname" class="input-text" placeholder="Last Name" required pattern="[A-Za-z]+" title="Last name should contain letters only.">
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <label for="address" class="form-label">Address: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <input type="text" name="address" class="input-text" placeholder="Address" required>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <label for="regNo" class="form-label">Reg. No.: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <input type="text" name="regNo" class="input-text" placeholder="Reg No." required pattern="\d+" title="Registration number should contain numbers only.">
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <label for="dob" class="form-label">Date of Birth: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <input type="date" name="dob" class="input-text" id="dob" required>
                </td>
            </tr>
            <tr>
                <td class="error" id="dobError" colspan="2"></td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <label for="gender" class="form-label">Gender: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <select name="gender" class="input-text" required>
                        <option value="" disabled selected>Select Gender</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <label for="role" class="form-label">Role: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2">
                    <select name="role" class="input-text" required>
                        <option value="" disabled selected>Select Role</option>
                        <option value="Student">Student</option>
                        <option value="Staff">Staff</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td class="label-td" colspan="2"></td>
            </tr>
            <tr>
                <td>
                    <input type="reset" value="Reset" class="login-btn btn-primary-soft btn">
                </td>
                <td>
                    <input type="submit" value="Next" class="login-btn btn-primary btn">
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <br>
                    <label for="" class="sub-text" style="font-weight: 280;">Already have an account&#63;</label>
                    <a href="login.php" class="hover-link1 non-style-link">Login</a>
                    <br><br><br>
                </td>
            </tr>
                </form>
            </tr>
        </table>
    </div>
    </center>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const dobInput = document.getElementById("dob");

            function calculateMaxDate() {
                const today = new Date();
                const maxDate = new Date(today.getFullYear() - 18, today.getMonth(), today.getDate());
                return maxDate.toISOString().split("T")[0];
            }

            dobInput.setAttribute("max", calculateMaxDate());

            document.querySelector("form").addEventListener("submit", function(event) {
                const selectedDate = new Date(dobInput.value);
                const maxDate = new Date(calculateMaxDate());
                if (selectedDate > maxDate) {
                    event.preventDefault();
                    document.getElementById("dobError").textContent = "You must be at least 18 years old.";
                }
            });
        });

        function validateForm() {
            const fname = document.forms["signupForm"]["fname"].value;
            const lname = document.forms["signupForm"]["lname"].value;
            const regNo = document.forms["signupForm"]["regNo"].value;

            if (!/^[A-Za-z]+$/.test(fname)) {
                alert("First name should contain letters only.");
                return false;
            }

            if (!/^[A-Za-z]+$/.test(lname)) {
                alert("Last name should contain letters only.");
                return false;
            }

            if (!/^\d+$/.test(regNo)) {
                alert("Registration number should contain numbers only.");
                return false;
            }

            return true;
        }
    </script>
     <script src="app.js"></script>
</body>
</html>
