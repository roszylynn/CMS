<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer-master/src/Exception.php';
require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';

include("../connection.php");

if (isset($_GET["id"])) {
    $pid = $_GET["id"];

    // Fetch appointment and patient details
    $query = "SELECT patient.pemail, patient.pname 
    FROM appointment 
    INNER JOIN patient ON appointment.pid = patient.pid 
    WHERE appointment.pid = ?";

    
    // Prepare statement
    $stmt = $database->prepare($query);
    $stmt->bind_param("i", $pid);;
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $patientEmail = $row["pemail"];
        $patientName = $row["pname"];

        // Email details
        $subject = "Appointment Confirmation";
        $message = "Dear $patientName,\n\nYour appointment has been confirmed.\n\nBest regards,\nYour Counseling Service";
        
        // Instantiate PHPMailer
        $mail = new PHPMailer;

        // SMTP configuration
        $mail->isSMTP();
        $mail->Host = 'smtp.example.com';  // Your SMTP host
        $mail->SMTPAuth = true;
        $mail->Username = "roszylynn05@gmail.com"; // your email address
        $mail->Password = "gjtg tchm soed zulm"; // app-specific password
        $mail->SMTPSecure = "ssl"; // secure transfer protocol to use
        $mail->Port = 465; // set the SMTP port

        // Email sender and recipient
        $mail->setFrom('roszylynn05@gmail.com', 'roseline'); // Sender's email and name
        $mail->addAddress($patientEmail); // Recipient's email

        // Email content
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $message;

        // Send the email
        if ($mail->send()) {
            echo 'Email sent successfully.';
        } else {
            echo 'Failed to send email.';
        }

        // Redirect back to appointments page
        header("Location: appointment.php");
        exit;
    } else {
        echo "Invalid appointment ID.";
    }
} else {
    echo "No appointment ID provided.";
}
?>
