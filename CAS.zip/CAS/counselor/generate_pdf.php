<?php
require('fpdf/fpdf.php');
include("../connection.php");
session_start();

if (isset($_SESSION["user"])) {
    if (($_SESSION["user"]) == "" or $_SESSION['usertype'] != 'd') {
        header("location: ../login.php");
    } else {
        $useremail = $_SESSION["user"];
    }
} else {
    header("location: ../login.php");
}

$userrow = $database->query("select * from counselor where lpcemail='$useremail'");
$userfetch = $userrow->fetch_assoc();
$userid = $userfetch["lpcid"];

$sqlmain = "select appointment.appoid, schedule.scheduleid, schedule.title, counselor.lpcname, patient.pname, schedule.scheduledate, schedule.scheduletime, appointment.apponum, appointment.appodate from schedule inner join appointment on schedule.scheduleid=appointment.scheduleid inner join patient on patient.pid=appointment.pid inner join counselor on schedule.lpcid=counselor.lpcid where counselor.lpcid=$userid";

if ($_POST) {
    if (!empty($_POST["sheduledate"])) {
        $sheduledate = $_POST["sheduledate"];
        $sqlmain .= " and schedule.scheduledate='$sheduledate'";
    }
}

$result = $database->query($sqlmain);

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 12);

$pdf->Cell(0, 10, 'My Appointments', 0, 1, 'C');
$pdf->Ln(10);

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(40, 10, 'Patient Name', 1);
$pdf->Cell(40, 10, 'Appointment Number', 1);
$pdf->Cell(40, 10, 'Session Title', 1);
$pdf->Cell(30, 10, 'Session Date', 1);
$pdf->Cell(30, 10, 'Session Time', 1);
$pdf->Ln();

$pdf->SetFont('Arial', '', 10);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $pdf->Cell(40, 10, $row["pname"], 1);
        $pdf->Cell(40, 10, $row["apponum"], 1);
        $pdf->Cell(40, 10, $row["title"], 1);
        $pdf->Cell(30, 10, $row["scheduledate"], 1);
        $pdf->Cell(30, 10, $row["scheduletime"], 1);
        $pdf->Ln();
    }
} else {
    $pdf->Cell(180, 10, 'No appointments found.', 1, 1, 'C');
}

$pdf->Output('D', 'Appointments.pdf');
?>
